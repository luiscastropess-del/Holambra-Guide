export default function PlacesPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Meus Lugares</h1>
      <p className="text-gray-600">Lista de lugares cadastrados...</p>
    </div>
  )
}
