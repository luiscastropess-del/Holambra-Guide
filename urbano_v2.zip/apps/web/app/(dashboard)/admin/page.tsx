'use client'

import { useAuth } from '@/hooks/useAuth'

export default function AdminPage() {
  const { user, logout } = useAuth()

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-lg shadow p-6">
          <h1 className="text-2xl font-bold mb-4">Dashboard Admin</h1>
          <p className="text-gray-600 mb-4">
            Bem-vindo, {user?.name || user?.email}!
          </p>
          <p className="text-sm text-gray-500 mb-6">
            Tenant ID: {user?.tenantId}
          </p>
          
          <button
            onClick={logout}
            className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700"
          >
            Sair
          </button>
        </div>
      </div>
    </div>
  )
}
