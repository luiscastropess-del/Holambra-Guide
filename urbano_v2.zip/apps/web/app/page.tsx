import Link from 'next/link'

export default function HomePage() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50">
      <div className="container mx-auto px-4 py-16">
        <div className="text-center">
          <h1 className="text-5xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent mb-6">
            Urbano Holambra
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            Descubra os melhores lugares da cidade
          </p>
          <div className="flex gap-4 justify-center">
            <Link
              href="/registro"
              className="px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition"
            >
              Criar conta
            </Link>
            <Link
              href="/login"
              className="px-6 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 transition"
            >
              Entrar
            </Link>
          </div>
        </div>
      </div>
    </main>
  )
}
