import { notFound } from 'next/navigation'

interface PageProps {
  params: {
    city: string
    category: string
  }
}

export default function CityCategoryPage({ params }: PageProps) {
  const { city, category } = params

  // Aqui futuramente buscar dados da API
  if (!city || !category) {
    notFound()
  }

  return (
    <main className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">
        {category} em {city}
      </h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <p className="text-gray-600 col-span-full">
          Lugares serão exibidos aqui...
        </p>
      </div>
    </main>
  )
}

export async function generateMetadata({ params }: PageProps) {
  return {
    title: `${params.category} em ${params.city} - Urbano`,
    description: `Descubra os melhores ${params.category} em ${params.city}`,
  }
}
