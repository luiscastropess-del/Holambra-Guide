import type { ApiResponse, AuthResponse, RegisterRequest, LoginRequest } from '@repo/types'

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3333'

class ApiClient {
  private token: string | null = null

  setToken(token: string) {
    this.token = token
    if (typeof window !== 'undefined') {
      localStorage.setItem('authToken', token)
    }
  }

  getToken(): string | null {
    if (this.token) return this.token
    if (typeof window !== 'undefined') {
      return localStorage.getItem('authToken')
    }
    return null
  }

  clearToken() {
    this.token = null
    if (typeof window !== 'undefined') {
      localStorage.removeItem('authToken')
    }
  }

  private async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<ApiResponse<T>> {
    const token = this.getToken()
    const headers: HeadersInit = {
      'Content-Type': 'application/json',
      ...options.headers,
    }

    if (token) {
      headers.Authorization = `Bearer ${token}`
    }

    const response = await fetch(`${API_URL}${endpoint}`, {
      ...options,
      headers,
    })

    const data = await response.json()

    if (!response.ok) {
      throw new Error(data.error || 'Erro na requisição')
    }

    return data
  }

  // Auth endpoints
  auth = {
    register: (data: RegisterRequest) =>
      this.request<AuthResponse>('/auth/register', {
        method: 'POST',
        body: JSON.stringify(data),
      }),

    login: (data: LoginRequest) =>
      this.request<AuthResponse>('/auth/login', {
        method: 'POST',
        body: JSON.stringify(data),
      }),

    me: () => this.request('/auth/me'),
  }

  // Places endpoints
  places = {
    list: (filters?: { city?: string; category?: string }) => {
      const params = new URLSearchParams(filters as any).toString()
      return this.request(`/places${params ? `?${params}` : ''}`)
    },

    getById: (id: string) => this.request(`/places/${id}`),

    create: (data: any) =>
      this.request('/places', {
        method: 'POST',
        body: JSON.stringify(data),
      }),
  }
}

export const api = new ApiClient()
