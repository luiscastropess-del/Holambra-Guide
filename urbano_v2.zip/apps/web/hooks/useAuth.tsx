'use client'

import React, { createContext, useContext, useEffect, useState } from 'react'
import { api } from '@/lib/api-client'
import type { SafeUser } from '@repo/types'

interface AuthContextType {
  user: SafeUser | null
  isLoading: boolean
  login: (email: string, password: string) => Promise<void>
  register: (data: any) => Promise<void>
  logout: () => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<SafeUser | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const token = api.getToken()
    if (token) {
      api.auth.me()
        .then(res => {
          if (res.success && res.data) {
            setUser(res.data as SafeUser)
          }
        })
        .catch(() => {
          api.clearToken()
        })
        .finally(() => setIsLoading(false))
    } else {
      setIsLoading(false)
    }
  }, [])

  const login = async (email: string, password: string) => {
    const res = await api.auth.login({ email, password })
    if (res.success && res.data) {
      api.setToken(res.data.token)
      setUser(res.data.user)
    }
  }

  const register = async (data: any) => {
    const res = await api.auth.register(data)
    if (res.success && res.data) {
      api.setToken(res.data.token)
      setUser(res.data.user)
    }
  }

  const logout = () => {
    api.clearToken()
    setUser(null)
  }

  return (
    <AuthContext.Provider value={{ user, isLoading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider')
  }
  return context
}
