import type { FastifyInstance } from 'fastify'
import { createPlaceController, listPlacesController, getPlaceController } from './place.controller.js'

export async function placeRoutes(app: FastifyInstance) {
  // Todas as rotas de place exigem autenticação (tenant injetado)
  app.post('/places', { preHandler: [app.authenticate] }, createPlaceController)
  app.get('/places', { preHandler: [app.authenticate] }, listPlacesController)
  app.get('/places/:id', { preHandler: [app.authenticate] }, getPlaceController)
}
