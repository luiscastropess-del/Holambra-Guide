import type { FastifyRequest, FastifyReply } from 'fastify'
import { createPlaceSchema } from './place.schema.js'
import { createPlace, getPlaces, getPlaceById } from './place.service.js'

export async function createPlaceController(
  request: FastifyRequest,
  reply: FastifyReply
) {
  const tenantId = request.tenantId!
  const input = createPlaceSchema.parse(request.body)
  
  const place = await createPlace(tenantId, input)
  
  return reply.status(201).send({
    success: true,
    data: place,
  })
}

export async function listPlacesController(
  request: FastifyRequest,
  reply: FastifyReply
) {
  const tenantId = request.tenantId!
  const { city, category } = request.query as any
  
  const places = await getPlaces(tenantId, { city, category })
  
  return reply.send({
    success: true,
    data: places,
  })
}

export async function getPlaceController(
  request: FastifyRequest<{ Params: { id: string } }>,
  reply: FastifyReply
) {
  const tenantId = request.tenantId!
  const { id } = request.params
  
  const place = await getPlaceById(tenantId, id)
  
  if (!place) {
    return reply.status(404).send({
      success: false,
      error: 'Lugar não encontrado',
    })
  }
  
  return reply.send({
    success: true,
    data: place,
  })
}
