import { prisma } from '../../lib/prisma.js'
import type { CreatePlaceInput } from './place.schema.js'

export async function createPlace(tenantId: string, data: CreatePlaceInput) {
  return prisma.place.create({
    data: {
      ...data,
      tenantId,
    },
  })
}

export async function getPlaces(tenantId: string, filters?: { city?: string; category?: string }) {
  return prisma.place.findMany({
    where: {
      tenantId,
      ...(filters?.city && { city: filters.city }),
      ...(filters?.category && { category: filters.category }),
    },
    orderBy: { createdAt: 'desc' },
  })
}

export async function getPlaceById(tenantId: string, placeId: string) {
  return prisma.place.findFirst({
    where: {
      id: placeId,
      tenantId,
    },
  })
}
