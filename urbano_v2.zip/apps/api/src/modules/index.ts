import type { FastifyInstance } from 'fastify'
import { authRoutes } from './auth/auth.routes.js'
import { placeRoutes } from './place/place.routes.js'

export async function registerRoutes(app: FastifyInstance) {
  await app.register(authRoutes)
  await app.register(placeRoutes)
}
