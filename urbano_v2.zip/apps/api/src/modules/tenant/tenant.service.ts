import { prisma } from '../../lib/prisma.js'

export async function createTenant(name: string, slug?: string) {
  const finalSlug = slug || name.toLowerCase().replace(/\s+/g, '-')
  
  const existing = await prisma.tenant.findUnique({
    where: { slug: finalSlug },
  })
  
  if (existing) {
    throw new Error('Slug já está em uso')
  }

  return prisma.tenant.create({
    data: {
      name,
      slug: finalSlug,
    },
  })
}
