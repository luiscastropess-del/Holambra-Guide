import type { FastifyInstance, FastifyRequest } from 'fastify'
import fp from 'fastify-plugin'

declare module 'fastify' {
  interface FastifyRequest {
    tenantId?: string
    user?: {
      id: string
      email: string
      role: string
      tenantId: string
    }
  }
}

export const tenantMiddleware = fp(async (app: FastifyInstance) => {
  // Hook executado antes de cada requisição
  app.addHook('preHandler', async (request: FastifyRequest) => {
    // Ignorar rotas públicas
    const publicRoutes = ['/auth/login', '/auth/register', '/health']
    if (publicRoutes.includes(request.url)) {
      return
    }

    try {
      // Verificar JWT
      await request.jwtVerify()
      const user = request.user as any

      if (!user || !user.tenantId) {
        throw app.httpErrors.unauthorized('Token inválido ou sem tenant')
      }

      // Anexar informações ao request
      request.tenantId = user.tenantId
      request.user = {
        id: user.sub || user.id,
        email: user.email,
        role: user.role,
        tenantId: user.tenantId,
      }
    } catch (err) {
      // Se não for rota pública, bloqueia
      if (!request.url.startsWith('/auth/')) {
        throw app.httpErrors.unauthorized('Autenticação necessária')
      }
    }
  })
})
