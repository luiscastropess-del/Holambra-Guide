import type { FastifyInstance } from 'fastify'
import { registerController, loginController, meController } from './auth.controller.js'

export async function authRoutes(app: FastifyInstance) {
  app.post('/auth/register', registerController)
  app.post('/auth/login', loginController)
  
  // Rota protegida para obter dados do usuário atual
  app.get('/auth/me', { preHandler: [app.authenticate] }, meController)
}
