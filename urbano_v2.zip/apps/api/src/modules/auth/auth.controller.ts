import type { FastifyRequest, FastifyReply } from 'fastify'
import { registerSchema, loginSchema } from './auth.schema.js'
import { registerUser, loginUser, generateToken } from './auth.service.js'

export async function registerController(
  request: FastifyRequest,
  reply: FastifyReply
) {
  const input = registerSchema.parse(request.body)
  
  const { user, tenant } = await registerUser(input)
  
  const token = generateToken(request.server, {
    userId: user.id,
    email: user.email,
    tenantId: tenant.id,
    role: user.role,
  })

  return reply.status(201).send({
    success: true,
    data: {
      user,
      tenant,
      token,
    },
  })
}

export async function loginController(
  request: FastifyRequest,
  reply: FastifyReply
) {
  const input = loginSchema.parse(request.body)
  
  const { user } = await loginUser(input)
  
  const token = generateToken(request.server, {
    userId: user.id,
    email: user.email,
    tenantId: user.tenantId,
    role: user.role,
  })

  return reply.send({
    success: true,
    data: {
      user,
      token,
    },
  })
}

export async function meController(
  request: FastifyRequest,
  reply: FastifyReply
) {
  return reply.send({
    success: true,
    data: request.user,
  })
}
