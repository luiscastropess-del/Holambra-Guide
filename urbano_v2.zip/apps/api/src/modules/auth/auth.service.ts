import { prisma } from '../../lib/prisma.js'
import { hashPassword, comparePassword } from '../../utils/hash.js'
import { createTenant } from '../tenant/tenant.service.js'
import { AppError } from '../../utils/errors.js'
import type { RegisterInput, LoginInput } from './auth.schema.js'

export async function registerUser(input: RegisterInput) {
  // Verificar se email já existe
  const existingUser = await prisma.user.findUnique({
    where: { email: input.email },
  })

  if (existingUser) {
    throw new AppError('Email já está em uso', 409)
  }

  // Criar tenant e usuário em transação
  const result = await prisma.$transaction(async (tx) => {
    // Criar tenant
    const tenant = await tx.tenant.create({
      data: {
        name: input.tenantName,
        slug: input.tenantSlug || input.tenantName.toLowerCase().replace(/\s+/g, '-'),
      },
    })

    // Hash da senha
    const hashedPassword = await hashPassword(input.password)

    // Criar usuário OWNER do tenant
    const user = await tx.user.create({
      data: {
        email: input.email,
        password: hashedPassword,
        name: input.name,
        role: 'OWNER',
        tenantId: tenant.id,
      },
    })

    return { user, tenant }
  })

  const { password, ...safeUser } = result.user
  return { user: safeUser, tenant: result.tenant }
}

export async function loginUser(input: LoginInput) {
  const user = await prisma.user.findUnique({
    where: { email: input.email },
    include: { tenant: true },
  })

  if (!user) {
    throw new AppError('Credenciais inválidas', 401)
  }

  const isValid = await comparePassword(input.password, user.password)
  if (!isValid) {
    throw new AppError('Credenciais inválidas', 401)
  }

  const { password, ...safeUser } = user
  return { user: safeUser }
}

export function generateToken(
  fastify: any,
  payload: { userId: string; email: string; tenantId: string; role: string }
) {
  return fastify.jwt.sign({
    sub: payload.userId,
    email: payload.email,
    tenantId: payload.tenantId,
    role: payload.role,
  })
}
