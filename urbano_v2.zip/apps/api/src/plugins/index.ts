import type { FastifyInstance } from 'fastify'
import fp from 'fastify-plugin'
import { setupCors } from './cors.js'
import { setupJwt } from './jwt.js'
import { setupMultipart } from './multipart.js'
import { setupSensible } from './sensible.js'
import { tenantMiddleware } from '../modules/tenant/tenant.middleware.js'

export async function setupPlugins(app: FastifyInstance) {
  await app.register(fp(setupCors))
  await app.register(fp(setupJwt))
  await app.register(fp(setupMultipart))
  await app.register(fp(setupSensible))
  await app.register(fp(tenantMiddleware))
}
