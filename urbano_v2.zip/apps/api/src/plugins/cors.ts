import cors from '@fastify/cors'
import type { FastifyInstance } from 'fastify'

export async function setupCors(app: FastifyInstance) {
  await app.register(cors, {
    origin: process.env.NODE_ENV === 'production' 
      ? ['https://urbano-7jey.onrender.com'] 
      : ['http://localhost:3000'],
    credentials: true,
  })
}
