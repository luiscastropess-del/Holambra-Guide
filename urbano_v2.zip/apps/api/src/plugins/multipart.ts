import multipart from '@fastify/multipart'
import type { FastifyInstance } from 'fastify'

export async function setupMultipart(app: FastifyInstance) {
  await app.register(multipart, {
    limits: {
      fileSize: 5 * 1024 * 1024, // 5MB
      files: 1,
    },
  })
}
