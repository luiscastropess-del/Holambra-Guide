import type { FastifyInstance } from 'fastify'
import fastifyJwt from '@fastify/jwt'

export async function setupJwt(app: FastifyInstance) {
  await app.register(fastifyJwt, {
    secret: process.env.JWT_SECRET || 'dev-secret',
    sign: {
      expiresIn: process.env.JWT_EXPIRES_IN || '7d',
    },
  })

  app.decorate('authenticate', async (request: any, reply: any) => {
    try {
      await request.jwtVerify()
    } catch (err) {
      reply.status(401).send({ success: false, error: 'Unauthorized' })
    }
  })
}

declare module 'fastify' {
  interface FastifyInstance {
    authenticate: (request: any, reply: any) => Promise<void>
  }
}
