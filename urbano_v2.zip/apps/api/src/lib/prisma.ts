import { prisma as prismaClient } from '@repo/database'

export const prisma = prismaClient
