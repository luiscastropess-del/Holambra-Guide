import 'dotenv/config'
import Fastify from 'fastify'
import { prisma } from './lib/prisma.js'
import { setupPlugins } from './plugins/index.js'
import { registerRoutes } from './modules/index.js'

const server = Fastify({
  logger: {
    transport: {
      target: 'pino-pretty',
      options: {
        translateTime: 'HH:MM:ss Z',
        ignore: 'pid,hostname',
      },
    },
  },
})

async function start() {
  try {
    // Setup plugins (CORS, JWT, Multipart, Sensible)
    await setupPlugins(server)

    // Health check
    server.get('/health', async () => {
      return { status: 'ok', timestamp: new Date().toISOString() }
    })

    // Register all module routes
    await registerRoutes(server)

    const port = Number(process.env.PORT) || 3333
    await server.listen({ port, host: '0.0.0.0' })

    console.log(`🚀 API rodando em http://localhost:${port}`)
  } catch (err) {
    server.log.error(err)
    process.exit(1)
  }
}

start()

// Graceful shutdown
process.on('SIGINT', async () => {
  await server.close()
  await prisma.$disconnect()
  process.exit(0)
})
