import type { User, Role } from '@repo/database'

export type SafeUser = Omit<User, 'password'>

export interface UserWithTenant extends SafeUser {
  tenant: { id: string; name: string; slug: string }
}

export interface LoginRequest {
  email: string
  password: string
}

export interface RegisterRequest {
  email: string
  password: string
  name?: string
  tenantName: string
  tenantSlug?: string
}

export interface AuthResponse {
  user: SafeUser
  token: string
}
