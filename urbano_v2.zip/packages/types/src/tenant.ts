import type { Tenant } from '@repo/database'

export type TenantPublic = Pick<Tenant, 'id' | 'name' | 'slug'>
