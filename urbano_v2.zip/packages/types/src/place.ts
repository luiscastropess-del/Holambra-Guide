import type { Place } from '@repo/database'

export type PlaceWithTenant = Place & {
  tenant: { id: string; name: string; slug: string }
}

export interface CreatePlaceInput {
  name: string
  description?: string
  address?: string
  city?: string
  category?: string
  latitude?: number
  longitude?: number
  phone?: string
  website?: string
  images?: string[]
}
